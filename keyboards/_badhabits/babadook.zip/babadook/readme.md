HotDox
========

![HotDox](https://cdn.shopify.com/s/files/1/1994/3097/products/Sunset_Ergodox.jpg?v=1540495379)

The HotDox is a modified version of the ErgoDox & ErgoDone(made by K.T.E.C.).


- Keyboard maintainer: [Layne](https://github.com/layne001365/qmk_firmware)

# Building the firmware

[Install the build tools.](https://docs.qmk.fm/#/getting_started_build_tools)

In the root directory of the repository, build the firmware with a command like:

    make hotdox:default

For more information on the layout option and other ones, see the [`make` guide](https://docs.qmk.fm/#/getting_started_make_guide).

# Flashing the firmware onto the keyboard
  https://docs.qmk.fm/#/newbs_flashing

